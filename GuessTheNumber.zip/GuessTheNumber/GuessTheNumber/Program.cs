﻿using System;

class Program
{
    static void Main()
    {

        //Declerations
        Random random = new Random();
        int min = 0, max = 100;
        int number = random.Next(min, max);
        Console.WriteLine("The Number Is: " + number);
    }
}